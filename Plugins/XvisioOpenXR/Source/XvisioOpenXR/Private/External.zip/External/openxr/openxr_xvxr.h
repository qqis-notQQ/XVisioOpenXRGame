#ifndef OPENXR_XVXR_H_
#define OPENXR_XVXR_H_ 1

/*
** Copyright (c) 2017-2022, The Khronos Group Inc.
**
** SPDX-License-Identifier: Apache-2.0 OR MIT
*/

/*
** This header is generated from the Khronos OpenXR XML API Registry.
**
*/
#include "openxr.h"

#ifdef __cplusplus
extern "C"
{
#endif


#define XR_XV_api 1
#define XR_XV_api_SPEC_VERSION            1
#define XR_XV_API_EXTENSION_NAME          "XR_XV_api"
#define XR_XV_HAND_JOINT_COUNT            52
#define XR_XV_DETECT_COUNT                64
#define XR_XV_ROTATION_SIZE               9
#define XR_XV_TRANSLATION_SIZE            3
#define XR_XV_PDM_CALIBRATION_SIZE        2
#define XR_XV_PDM_SIZE                    11

    typedef enum XrPlaneSourceXV {
        XR_PLANE_SOURCE_TOF_XV = 0,
        XR_PLANE_SOURCE_STEREO_XV = 1,
        XR_PLANE_SOURCE_TOF_NOSURFACE_XV = 2,
        XR_PLANE_SOURCE_MAX_ENUM_XV = 0x7FFFFFFF
    } XrPlaneSourceXV;
    typedef struct XvSkeletonXV {
        XrPosef     handPose[XR_XV_HAND_JOINT_COUNT];
        uint32_t    poseSize;
    } XvSkeletonXV;

    typedef struct XrObjectDataXV {
        XrVector3f     point;
        uint32_t       blobIndex;
        uint32_t       typeID;
        const char* typeName;
        double         confidence;
        double         x;
        double         y;
        double         width;
        double         height;
        uint32_t       pointsSize;
        XrVector3f* keypoints;
    } XrObjectDataXV;

    typedef struct XrCalibrationXV {
        double    ex_rotion[9];
        double    ex_trans[3];
        double    K[11];
    } XrCalibrationXV;

    typedef struct XrControllerXV {
        uint32_t      type;
        XrVector3f    position;
        XrVector4f    quaternion;
        float         confidence;
        uint32_t      keyTrigger;
        uint32_t      keySide;
        uint32_t      rocker_x;
        uint32_t      rocker_y;
        uint32_t      keyA;
        uint32_t      keyB;
    } XrControllerXV;

    typedef struct XrGazePointXV {
        uint32_t      gazeBitMask;
        XrVector3f    gazePoint;
        XrVector3f    rawPoint;
        XrVector3f    smoothPoint;
        XrVector3f    gazeOrigin;
        XrVector3f    gazeDirection;
        float         re;
        uint32_t      exDataBitMask;
    } XrGazePointXV;

    typedef struct XrGazePupilINFOXV {
        uint32_t      pupilBitMask;
        XrVector2f    pupilCenter;
        float         pupilDistance;
        float         pupilDiameter;
        float         pupilDiameterMM;
        float         pupilMinorAxis;
        float         pupilMinorAxisMM;
    } XrGazePupilINFOXV;

    typedef struct XrGazeDataXV {
        unsigned long long    timestamp;
        uint32_t              recommend;
        XrGazePointXV         gazePoints[2];
        XrGazePupilINFOXV     pupilInfo[2];
    } XrGazeDataXV;

    typedef struct XrXplanPackageXV {
        uint32_t       points_nb;
        char           idStr[32];
        XrVector3f     normal;
        uint32_t       verticesSize;
        XrVector3f* vertices;
        uint32_t       trianglesSize;
        XrVector3f* triangles;
        double         distance;
    } XrXplanPackageXV;

    typedef struct XrVector3i {
        int32_t    x;
        int32_t    y;
        int32_t    z;
    } XrVector3i;

    typedef struct XrSurfaceDataXV {
        uint32_t       mapId;
        uint32_t       version;
        uint32_t       id;
        uint32_t       verticesSize;
        XrVector3f* vertices;
        XrVector3f* vertexNormals;
        uint32_t       trianglesSize;
        XrVector3i* triangles;
        uint32_t       textureWidth;
        uint32_t       textureHeight;
    } XrSurfaceDataXV;

    typedef struct XrGazeCalibStatus {
        int32_t    enter_status;
        int32_t    collect_status;
        int32_t    setup_status;
        int32_t    compute_apply_status;
        int32_t    leave_status;
        int32_t    reset_status;
    } XrGazeCalibStatus;

    typedef struct XrGazeEyeExDataXV {
        uint32_t    eyeDataExBitMask;
        int32_t     blink;
        float       openness;
        float       eyelidUp;
        float       eyelidDown;
    } XrGazeEyeExDataXV;

    typedef struct XrEtEyeDataEx {
        unsigned long long    timestamp;
        int32_t               recommend;
        XrGazePointXV         recomGaze;
        XrGazePointXV         leftGaze;
        XrGazePointXV         rightGaze;
        XrGazePupilINFOXV     leftPupil;
        XrGazePupilINFOXV     rightPupil;
        XrGazeEyeExDataXV     leftExData;
        XrGazeEyeExDataXV     rightExData;
        float                 ipd;
        int32_t               leftEyeMove;
        int32_t               rightEyeMove;
    } XrEtEyeDataEx;

    typedef struct xrTagDataXV {
        uint32_t      tagID;
        XrVector3f    position;
        XrVector3f    orientation;
        XrVector4f    quaternion;
        uint32_t      edgeTimestamp;
        double        hostTimestamp;
        float         confidence;
    } xrTagDataXV;

    typedef struct xrConfigInfo {
        char    name[32];
        char    value[32];
    } xrConfigInfo;

    typedef struct XrSlamMapDataXV {
        XrVector3f    vertice;
    } XrSlamMapDataXV;

    typedef struct XrCSlamCallbackDataXV {
        uint32_t    map_quality;
        float       percent;
        uint32_t    status_of_saved_map;
    } XrCSlamCallbackDataXV;

    typedef struct xrTagArrayXV {
        xrTagDataXV    detect[XR_XV_DETECT_COUNT];
    } xrTagArrayXV;

    typedef struct XrCtransform {
        double    rotation[XR_XV_ROTATION_SIZE];
        double    translation[XR_XV_TRANSLATION_SIZE];
    } XrCtransform;

    typedef struct XrPdm {
        double    rotation[XR_XV_PDM_SIZE];
    } XrPdm;

    typedef struct XrPdmCalibration {
        XrCtransform    extrinsic;
        XrPdm           intrinsic;
    } XrPdmCalibration;

    typedef struct XrStereoPdmCalibration {
        XrPdmCalibration    calibrations[XR_XV_PDM_CALIBRATION_SIZE];
    } XrStereoPdmCalibration;

    typedef XrResult(XRAPI_PTR* PFN_xrCameraDistance)(XrSession session, double distance);
    typedef XrResult(XRAPI_PTR* PFN_xrGetConfigVariable)(XrSession session, xrConfigInfo* config);
    typedef XrResult(XRAPI_PTR* PFN_xrGetUpdateVariable)(XrSession session, xrConfigInfo* config);
    typedef XrResult(XRAPI_PTR* PFN_xrDeviceSetBrightnessXV)(XrSession session, uint32_t type, uint32_t brightness);
    typedef XrResult(XRAPI_PTR* PFN_xrGetHandTrackingDataXV)(XrSession session, XvSkeletonXV* skeleton);
    typedef XrResult(XRAPI_PTR* PFN_xrGetPoseDataXV)(XrSession session, XrPosef* pose, double predictionTime);
    typedef XrResult(XRAPI_PTR* PFN_xrResetSlamXV)(XrSession session, uint32_t type);
    typedef XrResult(XRAPI_PTR* PFN_xrStartHandTrackingXV)(XrSession session, uint32_t type);
    typedef XrResult(XRAPI_PTR* PFN_xrStartRgbStreamingXV)(XrSession session, uint32_t type, uint32_t solution, XrBool32 isStart);
    typedef XrResult(XRAPI_PTR* PFN_xrGetRgbStreamXV)(XrSession session, unsigned char* data, uint32_t type, uint32_t width, uint32_t height, double* timestamp);
    typedef XrResult(XRAPI_PTR* PFN_xrStartObjectTrackingXV)(XrSession session, char* modelPath, char* descriptorPath);
    typedef XrResult(XRAPI_PTR* PFN_xrGetObjectTrackingDataXV)(XrSession session, uint32_t* objNum, XrObjectDataXV* objectDatas);
    typedef XrResult(XRAPI_PTR* PFN_xrGetCalibrationDataXV)(XrSession session, uint32_t type, XrCalibrationXV* calibdata);
    typedef XrResult(XRAPI_PTR* PFN_xrGetControllerDataXV)(XrSession session, uint32_t type, XrControllerXV* data);
    typedef XrResult(XRAPI_PTR* PFN_xrStartDetectPlaneXV)(XrSession session, XrPlaneSourceXV sourceType);
    typedef XrResult(XRAPI_PTR* PFN_xrGetPlaneDataXV)(XrSession session, XrXplanPackageXV** data, uint32_t* size);
    typedef XrResult(XRAPI_PTR* PFN_xrStartSlamMapXV)(XrSession session);
    typedef XrResult(XRAPI_PTR* PFN_xrGetSlamMapXV)(XrSession session, uint32_t* objNum, XrSlamMapDataXV* objectDatas);
    typedef XrResult(XRAPI_PTR* PFN_xrGetCslamCallbackData)(XrSession session, XrCSlamCallbackDataXV* callbackData);
    typedef XrResult(XRAPI_PTR* PFN_xrLoadMapAndSwitchToCslamXV)(XrSession session, char* mapPath);
    typedef XrResult(XRAPI_PTR* PFN_xrSaveMapAndSwitchToCslamXV)(XrSession session, char* mapPath);
    typedef XrResult(XRAPI_PTR* PFN_xrStartGetSurfaceXV)(XrSession session);
    typedef XrResult(XRAPI_PTR* PFN_xrGetSurfaceDataXV)(XrSession session, XrSurfaceDataXV** data, uint32_t* size);
    typedef XrResult(XRAPI_PTR* PFN_xrGetDeviceCameraImageSize)(XrSession session, uint32_t type, uint32_t* width, uint32_t* height);
    typedef XrResult(XRAPI_PTR* PFN_xrGetDeviceCameraImageData)(XrSession session, unsigned char* data, uint32_t type, uint32_t width, uint32_t height, double* timestamp);
    typedef XrResult(XRAPI_PTR* PFN_xrGetRgbPixelPose)(XrSession session, XrBool32 is3dPose, XrVector3f* pointerPose, XrVector2f* rgbPixelPoint, float radius, double* timestamp);
    typedef XrResult(XRAPI_PTR* PFN_xrStopDetectTags)(XrSession session, uint32_t type);
    typedef XrResult(XRAPI_PTR* PFN_xrDetectTags)(XrSession session, unsigned char* tagFamily, double size, xrTagArrayXV* tagsArray, uint32_t* tagSize, uint32_t  arraySize, uint32_t type);
    typedef XrResult(XRAPI_PTR* PFN_xrIrisActive)(XrSession session, char* path, char* licence);
    typedef XrResult(XRAPI_PTR* PFN_xrIrisStop)(XrSession session, uint32_t type);
    typedef XrResult(XRAPI_PTR* PFN_xrIrisGetResult)(XrSession session, uint32_t type);
    typedef XrResult(XRAPI_PTR* PFN_xrStartGaze)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrStopGaze)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeSetConfigPath)(XrSession session, unsigned char* path);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationEnter)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationCollect)(XrSession session, float x, float y, float z, int32_t index, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationSetup)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationComputeApply)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationLeave)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationRetrieve)(XrSession session, unsigned char* file, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrUnsetGazeCallback)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrSlamStopGaze)(XrSession session, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGazeCalibrationQueryStatus)(XrSession session, XrGazeCalibStatus* status, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrSetExposure)(XrSession session, int32_t leftGain, float leftTimeMs, int32_t rightGain, float rightTimeMs, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrSetBright)(XrSession session, int32_t eye, int32_t led, int32_t brightness, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrGetGazeCallback)(XrSession session, XrEtEyeDataEx* data);
    typedef XrResult(XRAPI_PTR* PFN_xrReadStereoDisplayCalibration)(XrSession session, XrStereoPdmCalibration* calib);
    typedef XrResult(XRAPI_PTR* PFN_xrChangeIpd)(XrSession session, float distance, int32_t* ret);
    typedef XrResult(XRAPI_PTR* PFN_xrReadIpdParam)(XrSession session, float* distance);

#ifndef XR_NO_PROTOTYPES
#ifdef XR_EXTENSION_PROTOTYPES
    XRAPI_ATTR XrResult XRAPI_CALL xrCameraDistance(
        XrSession                                   session,
        double                                      distance);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetConfigVariable(
        XrSession                                   session,
        xrConfigInfo* config);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetUpdateVariable(
        XrSession                                   session,
        xrConfigInfo* config);

    XRAPI_ATTR XrResult XRAPI_CALL xrDeviceSetBrightnessXV(
        XrSession                                   session,
        uint32_t                                    type,
        uint32_t                                    brightness);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetHandTrackingDataXV(
        XrSession                                   session,
        XvSkeletonXV* skeleton);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetPoseDataXV(
        XrSession                                   session,
        XrPosef* pose,
        double                                      predictionTime);

    XRAPI_ATTR XrResult XRAPI_CALL xrResetSlamXV(
        XrSession                                   session,
        uint32_t                                    type);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartHandTrackingXV(
        XrSession                                   session,
        uint32_t                                    type);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartRgbStreamingXV(
        XrSession                                   session,
        uint32_t                                    type,
        uint32_t                                    solution,
        XrBool32                                    isStart);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetRgbStreamXV(
        XrSession                                   session,
        unsigned char* data,
        uint32_t                                    type,
        uint32_t                                    width,
        uint32_t                                    height,
        double* timestamp);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartObjectTrackingXV(
        XrSession                                   session,
        char* modelPath,
        char* descriptorPath);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetObjectTrackingDataXV(
        XrSession                                   session,
        uint32_t* objNum,
        XrObjectDataXV* objectDatas);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetCalibrationDataXV(
        XrSession                                   session,
        uint32_t                                    type,
        XrCalibrationXV* calibdata);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetControllerDataXV(
        XrSession                                   session,
        uint32_t                                    type,
        XrControllerXV* data);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartDetectPlaneXV(
        XrSession                                   session,
        XrPlaneSourceXV                             sourceType);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetPlaneDataXV(
        XrSession                                   session,
        XrXplanPackageXV** data,
        uint32_t* size);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartSlamMapXV(
        XrSession                                   session);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetSlamMapXV(
        XrSession                                   session,
        uint32_t* objNum,
        XrSlamMapDataXV* objectDatas);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetCslamCallbackData(
        XrSession                                   session,
        XrCSlamCallbackDataXV* callbackData);

    XRAPI_ATTR XrResult XRAPI_CALL xrLoadMapAndSwitchToCslamXV(
        XrSession                                   session,
        char* mapPath);

    XRAPI_ATTR XrResult XRAPI_CALL xrSaveMapAndSwitchToCslamXV(
        XrSession                                   session,
        char* mapPath);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartGetSurfaceXV(
        XrSession                                   session);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetSurfaceDataXV(
        XrSession                                   session,
        XrSurfaceDataXV** data,
        uint32_t* size);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetDeviceCameraImageSize(
        XrSession                                   session,
        uint32_t                                    type,
        uint32_t* width,
        uint32_t* height);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetDeviceCameraImageData(
        XrSession                                   session,
        unsigned char* data,
        uint32_t                                    type,
        uint32_t                                    width,
        uint32_t                                    height,
        double* timestamp);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetRgbPixelPose(
        XrSession                                   session,
        XrBool32                                    is3dPose,
        XrVector3f* pointerPose,
        XrVector2f* rgbPixelPoint,
        float                                       radius,
        double* timestamp);

    XRAPI_ATTR XrResult XRAPI_CALL xrStopDetectTags(
        XrSession                                   session,
        uint32_t                                    type);

    XRAPI_ATTR XrResult XRAPI_CALL xrDetectTags(
        XrSession                                   session,
        unsigned char* tagFamily,
        double                                      size,
        xrTagArrayXV* tagsArray,
        uint32_t* tagSize,
        uint32_t                                    arraySize,
        uint32_t                                    type);

    XRAPI_ATTR XrResult XRAPI_CALL xrIrisActive(
        XrSession                                   session,
        char* path,
        char* licence);

    XRAPI_ATTR XrResult XRAPI_CALL xrIrisStop(
        XrSession                                   session,
        uint32_t                                    type);

    XRAPI_ATTR XrResult XRAPI_CALL xrIrisGetResult(
        XrSession                                   session,
        uint32_t                                    type);

    XRAPI_ATTR XrResult XRAPI_CALL xrStartGaze(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrStopGaze(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeSetConfigPath(
        XrSession                                   session,
        unsigned char* path);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationEnter(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationCollect(
        XrSession                                   session,
        float                                       x,
        float                                       y,
        float                                       z,
        int32_t                                     index,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationSetup(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationComputeApply(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationLeave(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationRetrieve(
        XrSession                                   session,
        unsigned char* file,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrUnsetGazeCallback(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrSlamStopGaze(
        XrSession                                   session,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGazeCalibrationQueryStatus(
        XrSession                                   session,
        XrGazeCalibStatus* status,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrSetExposure(
        XrSession                                   session,
        int32_t                                     leftGain,
        float                                       leftTimeMs,
        int32_t                                     rightGain,
        float                                       rightTimeMs,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrSetBright(
        XrSession                                   session,
        int32_t                                     eye,
        int32_t                                     led,
        int32_t                                     brightness,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrGetGazeCallback(
        XrSession                                   session,
        XrEtEyeDataEx* data);

    XRAPI_ATTR XrResult XRAPI_CALL xrReadStereoDisplayCalibration(
        XrSession                                   session,
        XrStereoPdmCalibration* calib);

    XRAPI_ATTR XrResult XRAPI_CALL xrChangeIpd(
        XrSession                                   session,
        float                                       distance,
        int32_t* ret);

    XRAPI_ATTR XrResult XRAPI_CALL xrReadIpdParam(
        XrSession                                   session,
        float* distance);
#endif /* XR_EXTENSION_PROTOTYPES */
#endif /* !XR_NO_PROTOTYPES */

#define XR_XVISIO_hand_tracking 1
#define XR_XVISIO_hand_tracking_SPEC_VERSION 1
#define XR_XVISIO_HAND_TRACKING_EXTENSION_NAME "XR_XVISIO_hand_tracking"

#ifdef __cplusplus
}
#endif

#endif
